package com.actividad.actividad12;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

public class Activity2RecibirDatos extends AppCompatActivity {
    //declarar
    TextView ac2txtCorreo;
    TextView ac2txtContrasena;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity2_recibir_datos);

        //recibir los datos de la actividad anterior a traves de un bundle

        Bundle bundle = getIntent().getExtras();
        String correo = bundle.getString("correo");
        String contrasena = bundle.getString("contrasena");

        //identificar por id

        ac2txtCorreo = findViewById(R.id.txtCorreo);
        ac2txtContrasena = findViewById(R.id.txtPassword);

        //setear los datos en los textview

        ac2txtCorreo.setText(correo);
        ac2txtContrasena.setText(contrasena);

    }
}
package com.actividad.actividad12;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class Activity1EnviarDatos extends AppCompatActivity {
    //declarar
    Button btnEnviar;
    EditText txtcorreo;
    EditText txtcontrasena;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //identificar por id

        btnEnviar = findViewById(R.id.button);
        txtcorreo = findViewById(R.id.ET_email);
        txtcontrasena = findViewById(R.id.ET_password);

        //onclick

        btnEnviar.setOnClickListener(v -> {
            //validar que los campos no esten vacios
            if (txtcorreo.getText().toString().isEmpty()) {
                txtcorreo.setError("Ingrese un correo");
            } else if (txtcontrasena.getText().toString().isEmpty()){
                txtcontrasena.setError("Ingrese una contraseña");
            } else if (!txtcorreo.getText().toString().contains("@")) {

                //validar que el correo tenga @

                txtcorreo.setError("Ingrese un correo valido");
            } else if (txtcontrasena.getText().toString().length() < 6) {

                //validar que la contraseña tenga mas de 6 caracteres

                txtcontrasena.setError("Ingrese una contraseña de mas de 6 caracteres");

            } else {
                //enviar los datos a la siguiente actividad
                Intent intent = new Intent(Activity1EnviarDatos.this, Activity2RecibirDatos.class);
                intent.putExtra("correo", txtcorreo.getText().toString());
                intent.putExtra("contrasena", txtcontrasena.getText().toString());
                startActivity(intent);
            }
        });



    }
}